from flask import Blueprint, render_template, request, redirect, url_for, flash, current_app
from flask_login import current_user, login_required
from werkzeug.utils import secure_filename
import os
from models import Product, Category, Review, ReviewImage, Order, Banner
from forms import ReviewForm
from extensions import db

shop_bp = Blueprint('shop', __name__)

@shop_bp.route('/')
def index():
    products = Product.query.filter_by(is_active=True).all()
    categories = Category.query.all()
    banners = Banner.query.filter_by(is_active=True).order_by(Banner.display_order).all()
    return render_template('shop/index.html', products=products, categories=categories, banners=banners)

@shop_bp.route('/product/<int:product_id>', methods=['GET', 'POST'])
def product_detail(product_id):
    product = db.get_or_404(Product, product_id)
    if not product.is_active:
        return render_template('errors/404.html'), 404
    
    form = ReviewForm()
    if form.validate_on_submit():
        if not current_user.is_authenticated:
            flash('You must be logged in to post a review.', 'danger')
            return redirect(url_for('auth.login', next=request.url))
            
        review = Review(
            user_id=current_user.id,
            product_id=product.id,
            rating=int(form.rating.data),
            comment=form.comment.data
        )
        db.session.add(review)
        db.session.flush() # Get review.id
        
        # Handle Images
        files = request.files.getlist(form.photos.name)
        if files:
            upload_dir = os.path.join(current_app.root_path, 'static', 'uploads', 'reviews')
            os.makedirs(upload_dir, exist_ok=True)
            
            for file in files:
                if file and file.filename:
                    filename = secure_filename(file.filename)
                    # Unique filename
                    import uuid
                    unique_filename = f"{uuid.uuid4().hex}_{filename}"
                    file.save(os.path.join(upload_dir, unique_filename))
                    
                    review_image = ReviewImage(
                        review_id=review.id,
                        image_url=f"/static/uploads/reviews/{unique_filename}"
                    )
                    db.session.add(review_image)
        
        db.session.commit()
        flash('Review submitted successfully!', 'success')
        return redirect(url_for('shop.product_detail', product_id=product.id))

    # Calculate average rating
    reviews = product.reviews
    avg_rating = 0
    if reviews:
        avg_rating = sum([r.rating for r in reviews]) / len(reviews)
    
    return render_template('shop/product_detail.html', product=product, form=form, reviews=reviews, avg_rating=avg_rating)

@shop_bp.route('/category/<string:slug>')
def category_products(slug):
    category = Category.query.filter_by(slug=slug).first_or_404()
    # Price filtering
    min_price = request.args.get('min_price', type=float)
    max_price = request.args.get('max_price', type=float)
    
    query = Product.query.filter_by(category_id=category.id, is_active=True)
    if min_price is not None:
        query = query.filter(Product.price >= min_price)
    if max_price is not None:
        query = query.filter(Product.price <= max_price)
    
    products = query.all()
    categories = Category.query.all()
    return render_template('shop/category_products.html', category=category, products=products, categories=categories)

@shop_bp.route('/size-guide')
def size_guide():
    return render_template('shop/size_guide.html')

@shop_bp.route('/my-orders')
@login_required
def my_orders():
    """Display user's order history"""
    orders = Order.query.filter_by(user_id=current_user.id).order_by(Order.created_at.desc()).all()
    return render_template('shop/my_orders.html', orders=orders)

@shop_bp.route('/order/<int:order_id>')
@login_required
def order_detail(order_id):
    """Display detailed order tracking information"""
    order = db.get_or_404(Order, order_id)
    # Ensure user can only see their own orders
    if order.user_id != current_user.id:
        flash('Unauthorized access.', 'danger')
        return redirect(url_for('shop.index'))
    return render_template('shop/order_detail.html', order=order)

@shop_bp.route('/search')
def search():
    """Search products by name or description"""
    query = request.args.get('q', '').strip()
    
    if not query:
        flash('Please enter a search term.', 'warning')
        return redirect(url_for('shop.index'))
    
    # Search in product name, description, and category name
    keywords = query.split()
    search_filters = []
    
    for word in keywords:
        search_term = f"%{word}%"
        search_filters.append(db.or_(
            Product.name.ilike(search_term),
            Product.description.ilike(search_term),
            Category.name.ilike(search_term)
        ))
    
    # Price filtering
    min_price = request.args.get('min_price', type=float)
    max_price = request.args.get('max_price', type=float)
    
    filter_query = Product.query.join(Category).filter(
        db.and_(*search_filters),
        Product.is_active == True
    )
    
    if min_price is not None:
        filter_query = filter_query.filter(Product.price >= min_price)
    if max_price is not None:
        filter_query = filter_query.filter(Product.price <= max_price)
    
    products = filter_query.all()
    
    categories = Category.query.all()
    
    return render_template('shop/search_results.html', 
                          products=products, 
                          query=query, 
                          categories=categories)


