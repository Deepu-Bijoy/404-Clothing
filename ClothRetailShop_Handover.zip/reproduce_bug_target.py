import requests
import sys

URL = "http://localhost:5001"
TARGET_URL = f"{URL}/product/1"

s = requests.Session()

print(f"[INFO] Accessing {TARGET_URL}...", flush=True)
r = s.get(TARGET_URL)
print(f"Status: {r.status_code}", flush=True)

if r.status_code == 500:
    print(f"[SUCCESS] Reproduced 500 Error on {TARGET_URL}!", flush=True)
    sys.exit(0)
else:
    print(f"[FAILURE] Did not reproduce 500 error. Status: {r.status_code}", flush=True)
    sys.exit(1)
