import requests
import re
import sys

URL = "http://localhost:5001"
# Login details
LOGIN_URL = f"{URL}/auth/login"
ROUTES = [
    "/admin",
    "/admin/products",
    "/admin/orders", 
    "/",
    "/shop"
]

s = requests.Session()

print(f"[INFO] Fetching {LOGIN_URL}...", flush=True)
try:
    r = s.get(LOGIN_URL)
except Exception as e:
    print(f"[ERROR] Connection failed: {e}", flush=True)
    sys.exit(1)

if r.status_code != 200:
    print(f"[ERROR] Failed to load login page. Status: {r.status_code}", flush=True)
    sys.exit(1)

# Extract CSRF
match = re.search(r'name="csrf_token"[^>]*value="([^"]+)"', r.text)
if not match:
    match = re.search(r'value="([^"]+)"[^>]*name="csrf_token"', r.text)
if not match:
    # Try finding any hidden input with csrf_token in name?
    # Or just use beautifulsoup regex if desperate
    print("[ERROR] Could not find CSRF token.", flush=True)
    sys.exit(1)

csrf_token = match.group(1)

# Login
login_data = {'email': 'admin@example.com', 'password': 'admin123', 'csrf_token': csrf_token, 'submit': 'Login'}
print(f"[INFO] Logging in...", flush=True)
r = s.post(LOGIN_URL, data=login_data)
if "Invalid email or password" in r.text or r.status_code != 200:
    print(f"[ERROR] Login failed. Status: {r.status_code}", flush=True)
    print(r.text[:200]) # Print beginning of response
    # Proceed anyway to check protected routes if possible? No.
    if "/auth/login" in r.url:
         sys.exit(1)

print("[INFO] Login successful.", flush=True)

# Check Routes
for path in ROUTES:
    full_url = f"{URL}{path}"
    print(f"[INFO] Accessing {full_url}...", flush=True)
    r = s.get(full_url)
    print(f"Status: {r.status_code}", flush=True)
    if r.status_code == 500:
        print(f"[SUCCESS] Reproduced 500 Error on {path}!", flush=True)
        # We successfully reproduced it, so we can stop.
        # The traceback should be in the server logs.
        sys.exit(0)

print("[INFO] Done checking routes. No 500 error found.", flush=True)
