import requests
import re
import sys

URL = "http://localhost:5001"
LOGIN_URL = f"{URL}/auth/login"
ADD_PRODUCT_URL = f"{URL}/admin/product/add"

s = requests.Session()

# 1. Login
print(f"[INFO] logging in...", flush=True)
r = s.get(LOGIN_URL)
match = re.search(r'name="csrf_token"[^>]*value="([^"]+)"', r.text)
if not match:
    match = re.search(r'value="([^"]+)"[^>]*name="csrf_token"', r.text)
if not match:
    print("[ERROR] No CSRF token found", flush=True)
    sys.exit(1)
csrf_token = match.group(1)

login_data = {
    'email': 'admin@example.com',
    'password': 'admin123',
    'csrf_token': csrf_token,
    'submit': 'Login'
}
s.post(LOGIN_URL, data=login_data)

# 2. Add Product
print(f"[INFO] Attempting to add product...", flush=True)

# Need CSRF token for the add form? Usually yes.
# It might be the same token if checks aren't rotating per request, 
# but let's fetch the page to be sure and get a fresh one if needed.
r = s.get(f"{URL}/admin/products")
match = re.search(r'name="csrf_token"[^>]*value="([^"]+)"', r.text)
if match:
    csrf_token = match.group(1)

files = {
    # 'image_files': open('test.jpg', 'rb') # Optional
}
data = {
    'name': 'Debug Product',
    'description': 'Created by reproduction script',
    'price': '99.99',
    'stock': '10',
    'category_id': '1', # Assuming category 1 exists
    'image_url': 'http://example.com/image.png',
    'csrf_token': csrf_token
}

r = s.post(ADD_PRODUCT_URL, data=data)
print(f"Status Code: {r.status_code}", flush=True)
print(r.text[:500], flush=True)

if r.status_code == 500:
    print("[SUCCESS] Reproduced 500 error on Add Product", flush=True)
else:
    print("[INFO] Did not reproduce 500 error", flush=True)
