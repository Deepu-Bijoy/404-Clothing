from app import create_app
from models import Category
from extensions import db

app = create_app()

with app.app_context():
    categories = Category.query.all()
    print("CATEGORIES_START")
    for cat in categories:
        print(f"ID: {cat.id}, Name: {cat.name}, Slug: {cat.slug}")
    print("CATEGORIES_END")
