import unittest
from app import create_app
from extensions import db
from models import User, Product, Category, Review, ReviewImage
from flask_login import login_user

class TestReviews(unittest.TestCase):
    def setUp(self):
        self.app = create_app()
        self.app.config['TESTING'] = True
        self.app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///:memory:'
        self.app.config['WTF_CSRF_ENABLED'] = False
        self.app_context = self.app.app_context()
        self.app_context.push()
        db.create_all()

        # Create Test Data
        self.user = User(name='Test User', email='test@example.com')
        self.user.set_password('password')
        db.session.add(self.user)
        
        self.category = Category(name='Test Cat', slug='test-cat')
        db.session.add(self.category)
        db.session.commit() # Commit to get ID for product
        
        self.product = Product(name='Test Product', description='Desc', price=100.0, category_id=self.category.id)
        db.session.add(self.product)
        db.session.commit()

        self.client = self.app.test_client()

    def tearDown(self):
        db.session.remove()
        db.drop_all()
        self.app_context.pop()

    def login(self):
        return self.client.post('/auth/login', data=dict(
            email='test@example.com',
            password='password'
        ), follow_redirects=True)

    def test_add_review(self):
        self.login()
        response = self.client.post(f'/product/{self.product.id}', data=dict(
            rating='5',
            comment='Great product!',
            photos=[]
        ), follow_redirects=True)
        
        self.assertEqual(response.status_code, 200)
        self.assertIn(b'Great product!', response.data)
        
        review = Review.query.first()
        self.assertIsNotNone(review)
        self.assertEqual(review.rating, 5)
        self.assertEqual(review.comment, 'Great product!')

if __name__ == '__main__':
    unittest.main()
