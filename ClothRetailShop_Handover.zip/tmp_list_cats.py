from app import create_app
from extensions import db
from models import Category, Product

app = create_app()
with app.app_context():
    categories = Category.query.all()
    print(f"ID | Name | Slug | Product Count")
    print("-" * 45)
    for c in categories:
        count = Product.query.filter_by(category_id=c.id).count()
        print(f"{c.id} | {c.name} | {c.slug} | {count}")
