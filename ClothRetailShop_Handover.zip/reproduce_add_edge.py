import requests
import re
import sys

URL = "http://localhost:5001"
LOGIN_URL = f"{URL}/auth/login"
ADD_PRODUCT_URL = f"{URL}/admin/product/add"

s = requests.Session()

# Login
r = s.get(LOGIN_URL)
match = re.search(r'name="csrf_token"[^>]*value="([^"]+)"', r.text)
if match:
    csrf_token = match.group(1)
    s.post(LOGIN_URL, data={'email': 'admin@example.com', 'password': 'admin123', 'csrf_token': csrf_token, 'submit': 'Login'})

# Get CSRF
r = s.get(f"{URL}/admin/products")
match = re.search(r'name="csrf_token"[^>]*value="([^"]+)"', r.text)
csrf_token = match.group(1) if match else ''

# Test 3: Non-numeric price (Should Crash with ValueError -> 500)
print(f"[INFO] Testing Non-Numeric Price...", flush=True)
data = {
    'name': 'Bad Price Product',
    'description': 'Desc',
    'price': 'abc', # Invalid
    'stock': '10',
    'category_id': '1',
    'csrf_token': csrf_token
}
r = s.post(ADD_PRODUCT_URL, data=data)
print(f"Status 3: {r.status_code}", flush=True)
if r.status_code == 500:
    print("[SUCCESS] Reproduced 500 with non-numeric price", flush=True)

# Test 4: Invalid Category ID (Should likely crash with IntegrityError -> 500)
print(f"[INFO] Testing Invalid Category...", flush=True)
data = {
    'name': 'Bad Category Product',
    'description': 'Desc',
    'price': '10.0',
    'stock': '10',
    'category_id': '99999', # Non-existent
    'csrf_token': csrf_token
}
r = s.post(ADD_PRODUCT_URL, data=data)
print(f"Status 4: {r.status_code}", flush=True)
if r.status_code == 500:
    print("[SUCCESS] Reproduced 500 with invalid category", flush=True)

