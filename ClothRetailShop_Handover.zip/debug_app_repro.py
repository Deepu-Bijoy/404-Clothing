from app import create_app
import os

app = create_app()

if __name__ == '__main__':
    # Set different port to avoid conflict
    app.run(debug=True, port=5001)
